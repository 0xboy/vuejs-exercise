new Vue({
  el: '#exercise',
  data: {
    array: ['Gökhan', 'Defne', 'Berk', 'Özge'],
    customObject: {
      title: 'Game of Thrones',
      author: 'George R.R',
      books: '7'
    },
    testData: {
      name: 'TESTOBJECT', 
      id: 10,
      data: [1.67, 1.33, 0.98, 2.21]
    }
  }
});
