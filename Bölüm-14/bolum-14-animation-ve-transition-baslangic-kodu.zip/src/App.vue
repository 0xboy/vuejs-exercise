<template>
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <h3>Animation ve Transition</h3>
        <hr>
      </div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>
</style>
