<template>
  <div>
    <p class="text-center"> Bu çok güzel bir anıdır...</p>
  </div>
</template>
<script>
</script>
<style scoped>
  div {
    border: 1px solid #ccc;
    box-shadow: 1px 1px 2px #666;
    padding: 20px 20px;
    margin-top: 20px;
  }
</style>
